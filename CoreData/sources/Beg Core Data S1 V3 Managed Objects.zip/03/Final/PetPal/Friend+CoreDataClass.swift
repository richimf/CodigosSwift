//
//  Friend+CoreDataClass.swift
//  PetPal
//
//  Created by Brian on 9/20/17.
//  Copyright © 2017 Razeware. All rights reserved.
//
//

import Foundation
import CoreData


public class Friend: NSManagedObject {

}
